document.addEventListener('DOMContentLoaded', function() {
  // Tab switching functionality
  const tabs = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.tab-content');
  
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs and contents
      tabs.forEach(t => t.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      // Add active class to clicked tab and corresponding content
      tab.classList.add('active');
      const contentId = tab.id.replace('tab-', '') + '-content';
      document.getElementById(contentId).classList.add('active');
      
      // If bookmarks tab is selected, load bookmarks
      if (tab.id === 'tab-bookmarks') {
        loadBookmarks();
      }
    });
  });
  
  // Search functionality
  const searchInput = document.getElementById('search-bookmarks');
  searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    filterBookmarks(searchTerm);
  });
  
  // Initialize by loading bookmarks
  if (document.getElementById('tab-bookmarks').classList.contains('active')) {
    loadBookmarks();
  }
});

// Load bookmarks from storage
function loadBookmarks() {
  const bookmarksList = document.getElementById('bookmarks-list');
  const emptyState = bookmarksList.querySelector('.empty-state');
  
  chrome.storage.local.get('savedArticles', function(data) {
    const savedArticles = data.savedArticles || [];
    
    // Clear previous bookmarks
    while (bookmarksList.firstChild) {
      bookmarksList.removeChild(bookmarksList.firstChild);
    }
    
    if (savedArticles.length === 0) {
      // Show empty state
      const emptyDiv = document.createElement('div');
      emptyDiv.className = 'empty-state';
      emptyDiv.textContent = 'No bookmarked articles yet';
      bookmarksList.appendChild(emptyDiv);
    } else {
      // Sort bookmarks by date (newest first)
      savedArticles.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      // Create bookmark items
      savedArticles.forEach((article, index) => {
        const bookmarkItem = createBookmarkItem(article, index);
        bookmarksList.appendChild(bookmarkItem);
      });
    }
  });
}

// Create a bookmark item element
function createBookmarkItem(article, index) {
  const div = document.createElement('div');
  div.className = 'bookmark-item';
  div.dataset.index = index;
  
  // Format date
  const date = new Date(article.date);
  const formattedDate = date.toLocaleDateString() + ' ' + 
    date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
  
  // Get sentiment percentages
  const positivePercent = article.analysisData.positivePercent || '0%';
  const negativePercent = article.analysisData.negativePercent || '0%';
  
  div.innerHTML = `
    <div class="bookmark-title">${article.title}</div>
    <div class="bookmark-date">Saved on ${formattedDate}</div>
    <div class="bookmark-stats">
      <span style="color: green">Positive: ${positivePercent}</span>
      <span style="color: red">Negative: ${negativePercent}</span>
    </div>
    <div class="bookmark-actions">
      <button class="bookmark-btn open-btn">Open Article</button>
      <button class="bookmark-btn delete-btn">Delete</button>
    </div>
  `;
  
  // Add event listeners
  div.querySelector('.open-btn').addEventListener('click', () => {
    chrome.tabs.create({ url: article.url });
  });
  
  div.querySelector('.delete-btn').addEventListener('click', () => {
    deleteBookmark(index);
  });
  
  return div;
}

// Delete a bookmark
function deleteBookmark(index) {
  chrome.storage.local.get('savedArticles', function(data) {
    const savedArticles = data.savedArticles || [];
    savedArticles.splice(index, 1);
    
    chrome.storage.local.set({savedArticles}, function() {
      loadBookmarks(); // Reload bookmarks after deletion
    });
  });
}

// Filter bookmarks based on search term
function filterBookmarks(searchTerm) {
  const bookmarkItems = document.querySelectorAll('.bookmark-item');
  
  bookmarkItems.forEach(item => {
    const title = item.querySelector('.bookmark-title').textContent.toLowerCase();
    if (title.includes(searchTerm)) {
      item.style.display = 'block';
    } else {
      item.style.display = 'none';
    }
  });
  
  // Check if any results are visible
  let anyVisible = false;
  bookmarkItems.forEach(item => {
    if (item.style.display !== 'none') {
      anyVisible = true;
    }
  });
  
  // Show no results message if needed
  const bookmarksList = document.getElementById('bookmarks-list');
  let noResults = bookmarksList.querySelector('.no-results');
  
  if (!anyVisible && searchTerm && bookmarkItems.length > 0) {
    if (!noResults) {
      noResults = document.createElement('div');
      noResults.className = 'empty-state no-results';
      noResults.textContent = 'No results found';
      bookmarksList.appendChild(noResults);
    }
  } else if (noResults) {
    bookmarksList.removeChild(noResults);
  }
}