console.log("background.js loaded");

function fetchSvg(url, sendResponse) {
  fetch(url)
    .then((response) => response.text())
    .then((data) => {
      sendResponse({ svg: data });
    })
    .catch((error) => {
      console.error("Error fetching SVG:", error);
      sendResponse({ error: error.toString() });
    });
}

const iconPaths = {
  fetchIconShare: "icons/share.svg",
  fetchIconInfo: "icons/info.svg",
  fetchIconFlag: "icons/flag.svg",
  fetchIconClose: "icons/close.svg",
  fetchIconBookmark: "icons/bookmark.svg",
};

// API endpoint for the GodsEye backend
const BACKEND_API_URL = "http://localhost:8502/api/analyze";

// Content types for the analysis
const types = {
  summary: "Summary",
  positive: "Positive",
  negative: "Negative",
  authenticity: "Authenticity",
};

// Fetch news analysis from the GodsEye backend
async function fetchContentInfo(sendResponse, type, url) {
  try {
    // If no URL provided, we'll use mock data for testing
    if (!url) {
      console.log("No URL provided, using mock data");
      setTimeout(() => {
        sendResponse({ 
          content: types[type],
          mockData: true
        });
      }, 500);
      return;
    }
    
    // Fetch analysis from backend API
    console.log(`Fetching analysis for URL: ${url}`);
    
    const response = await fetch(`${BACKEND_API_URL}?url=${encodeURIComponent(url)}`);
    
    if (!response.ok) {
      throw new Error(`API responded with status ${response.status}`);
    }
    
    const data = await response.json();
    
    // Map the response to the content type requested
    let content = "Content not available";
    let additionalData = {};
    
    if (data) {
      switch(type) {
        case "summary":
          content = data.title || "No summary available";
          break;
        case "positive":
          content = `Positive sentiment detected in this article.`;
          additionalData.percentage = data.positive_percentage || "0%";
          break;
        case "negative":
          content = `Negative sentiment detected in this article.`;
          additionalData.percentage = data.negative_percentage || "0%";
          break;
        case "authenticity":
          if (data.authenticity) {
            const misinfoStatus = data.authenticity["Misinformation Status"];
            const factCheck = data.authenticity["Fact Check"];
            content = misinfoStatus?.Misinformation === "Yes" 
              ? "This article may contain misinformation." 
              : "No significant misinformation detected in this article.";
            
            additionalData.status = factCheck?.article_status || "Unknown";
            additionalData.claims = factCheck?.verified_claims || [];
          } else {
            content = "Authenticity analysis not available.";
          }
          break;
      }
    }
    
    sendResponse({ 
      content: content,
      additionalData: additionalData,
      fullData: data
    });
    
  } catch (error) {
    console.error("Error fetching content:", error);
    sendResponse({ 
      error: error.toString(),
      content: `Unable to analyze. ${error.message}`,
      fallback: true
    });
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.text in iconPaths) {
    fetchSvg(chrome.runtime.getURL(iconPaths[msg.text]), sendResponse);
    return true; // keeps the message channel open until sendResponse is called
  } else if (msg.text === "fetchContentFor") {
    // Ensure msg.type is valid before proceeding
    if (msg.type in types) {
      fetchContentInfo(sendResponse, msg.type, msg.url);
    } else {
      console.error("Invalid or missing type for content fetch");
      sendResponse({ error: "Invalid or missing type" });
    }
    return true; // keeps the message channel open until sendResponse is called
  } else {
    console.error(`Unknown message text: ${msg.text}`);
    sendResponse({ error: `Unknown message text: ${msg.text}` });
  }
});
